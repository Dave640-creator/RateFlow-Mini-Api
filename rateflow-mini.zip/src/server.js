const express = require("express");
const swaggerUi = require("swagger-ui-express");
const crypto = require("crypto");

const app = express();
app.use(express.json());

const API_KEY = "rf_" + crypto.randomBytes(12).toString("hex");

const rates = {
  USD: { PHP: 58.00, EUR: 0.86, JPY: 156.00, SGD: 1.28, GBP: 0.75 },
  PHP: { USD: 1/58, EUR: 0.86/58, JPY: 156/58, SGD: 1.28/58, GBP: 0.75/58 }
};

function auth(req,res,next) {
  if (req.path === "/health" || req.path === "/docs") return next();
  if (req.headers["x-api-key"] !== API_KEY)
    return res.status(401).json({success:false,error:"Invalid API key"});
  next();
}

app.use(auth);

app.get("/health",(req,res)=>res.json({
  status:"ok",
  service:"RateFlow API",
  version:"1.0.0"
}));

app.get("/v1/convert",(req,res)=>{
  const from=(req.query.from||"USD").toUpperCase();
  const to=(req.query.to||"PHP").toUpperCase();
  const amount=Number(req.query.amount);

  if(!Number.isFinite(amount))
    return res.status(400).json({success:false,error:"Invalid amount"});

  const rate = rates[from]?.[to];
  if(rate === undefined)
    return res.status(400).json({success:false,error:"Currency pair not supported"});

  res.json({
    success:true,
    data:{
      from,to,
      amount,
      rate,
      converted:Number((amount*rate).toFixed(2)),
      timestamp:new Date().toISOString()
    }
  });
});

app.get("/v1/rates",(req,res)=>{
  const base=(req.query.base||"USD").toUpperCase();
  if(!rates[base])
    return res.status(400).json({success:false,error:"Unsupported base currency"});
  res.json({success:true,data:{base,rates:rates[base]}});
});

const swagger={
  openapi:"3.0.0",
  info:{title:"RateFlow API",version:"1.0.0"},
  servers:[{url:"http://localhost:3000"}],
  components:{securitySchemes:{ApiKey:{type:"apiKey",in:"header",name:"x-api-key"}}},
  security:[{ApiKey:[]}],
  paths:{
    "/v1/convert":{
      get:{
        summary:"Convert currencies",
        parameters:[
          {name:"from",in:"query",schema:{type:"string"},example:"USD"},
          {name:"to",in:"query",schema:{type:"string"},example:"PHP"},
          {name:"amount",in:"query",schema:{type:"number"},example:100}
        ],
        responses:{"200":{description:"Conversion result"}}
      }
    },
    "/v1/rates":{
      get:{
        summary:"Get exchange rates",
        parameters:[{name:"base",in:"query",schema:{type:"string"},example:"USD"}],
        responses:{"200":{description:"Rates"}}
      }
    }
  }
};

app.use("/docs",swaggerUi.serve,swaggerUi.setup(swagger));

app.listen(3000,()=>{
  console.log("RateFlow API: http://localhost:3000");
  console.log("Swagger: http://localhost:3000/docs");
  console.log("Your API key:",API_KEY);
});
