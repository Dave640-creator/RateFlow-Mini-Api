# RateFlow Mini

Small working Currency API MVP.

## Install
npm install

## Run
npm start

Copy the API key printed in the terminal.

## Example
GET /v1/convert?from=USD&to=PHP&amount=100

Header:
x-api-key: YOUR_API_KEY

Swagger:
http://localhost:3000/docs

NOTE: The included rates are demo rates. Connect a licensed live FX provider before selling this as a live-rate service.
